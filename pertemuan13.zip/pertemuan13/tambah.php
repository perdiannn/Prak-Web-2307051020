<?php
include 'koneksi.php';
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $npm = $_POST['npm'];
    $query = "INSERT INTO mahasiswa (nama, npm) VALUES ('$nama', '$npm')";

    mysqli_query($conn, $query);

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Tambah Mahasiswa</title>
</head>

<body>
    <h2>Tambah Data Mahasiswa</h2>
    <form method="POST">
        <label>Nama:</label><br>
        <input type="text" name="nama" required>
        <br><br>

        <label>NPM:</label><br>
        <input type="text" name="npm" required>
        <br><br>

        <button type="submit" name="simpan">Simpan</button>
    </form>

    <br>
    <a href="index.php">Kembali</a>
</body>

</html>