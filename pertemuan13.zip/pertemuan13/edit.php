<?php
include 'koneksi.php';

// Mengambil ID mahasiswa
if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET['id'];

// Mengambil data mahasiswa berdasarkan ID
$stmt = mysqli_prepare(
    $conn,
    "SELECT nama, npm FROM mahasiswa WHERE id = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $nama, $npm);

if (!mysqli_stmt_fetch($stmt)) {
    mysqli_stmt_close($stmt);
    header("Location: index.php");
    exit;
}

mysqli_stmt_close($stmt);

// Memperbarui data mahasiswa
if (isset($_POST['update'])) {
    $namaBaru = $_POST['nama'];
    $npmBaru = $_POST['npm'];

    $stmt = mysqli_prepare(
        $conn,
        "UPDATE mahasiswa SET nama = ?, npm = ? WHERE id = ?"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "ssi",
        $namaBaru,
        $npmBaru,
        $id
    );

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Mahasiswa</title>
</head>
<body>

    <h2>Edit Data Mahasiswa</h2>

    <form method="POST">
        <label>Nama:</label><br>
        <input
            type="text"
            name="nama"
            value="<?= htmlspecialchars($nama); ?>"
            required
        >
        <br><br>

        <label>NPM:</label><br>
        <input
            type="text"
            name="npm"
            value="<?= htmlspecialchars($npm); ?>"
            required
        >
        <br><br>

        <button type="submit" name="update">Update</button>
    </form>

    <br>
    <a href="index.php">Kembali</a>

</body>
</html>
